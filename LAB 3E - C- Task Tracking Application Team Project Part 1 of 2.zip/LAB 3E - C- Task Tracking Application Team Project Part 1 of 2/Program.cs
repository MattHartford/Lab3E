﻿using System;

namespace LAB_3E___C__Task_Tracking_Application_Team_Project_Part_1_of_2
    {
    static class Program
        {
        static void Main( )
            {
                {
                Greeting();
                StartMenu();
                }
            }
            static void StartMenu( )
                {
                Console.WriteLine("Would you like To see your Task List?");
                Console.WriteLine("if so type y for YES or n for No. :    ");
                string Confirm = Console.ReadLine();
                if (Confirm == "y")
                    {
                    Console.WriteLine("Here is what you have left to complete.");
                    }
                else if (Confirm == "n")
                    {
                    Console.WriteLine("Exiting program");
                    Console.WriteLine("Thanks for stopping by!");
                    Console.ReadLine();
                    }
                }
                static void Greeting()
                    {
                _ = DateTime.Now;
                if (DateTime.Now.Hour < 12)
                        {
                        Console.WriteLine("Good Morning User");

                        }
                    else if (DateTime.Now.Hour < 17)
                        {
                        Console.WriteLine("Good Afternoon User");
                        }
                    else
                        {
                        Console.WriteLine("Good Evening User");
                        }
                    }
                }
            }
        
    
	